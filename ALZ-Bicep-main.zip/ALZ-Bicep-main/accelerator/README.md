# ALZ Bicep Accelerator

This repo contains the Azure Landing Zones Bicep Accelerator. For additional information on the Accelerator, please refer to the [Wiki](https://github.com/Azure/ALZ-Bicep/wiki/Accelerator).
